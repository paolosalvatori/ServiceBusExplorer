﻿namespace Microsoft.Azure.ServiceBusExplorer.Enums
{
    public enum MessageDirection
    {
        Send,
        Receive
    }
}
