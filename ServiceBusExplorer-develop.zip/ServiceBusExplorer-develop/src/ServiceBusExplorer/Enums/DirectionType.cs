﻿
namespace Microsoft.Azure.ServiceBusExplorer.Enums
{
    public enum DirectionType
    {
        Send,
        Receive
    }
}
