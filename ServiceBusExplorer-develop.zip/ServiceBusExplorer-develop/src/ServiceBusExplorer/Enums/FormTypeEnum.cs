﻿namespace Microsoft.Azure.ServiceBusExplorer.Enums
{
    public enum FormTypeEnum
    {
        Send,
        Test,
        Listener
    }
}
