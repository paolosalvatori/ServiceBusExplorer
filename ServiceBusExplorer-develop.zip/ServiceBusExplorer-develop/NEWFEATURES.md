- HandlePartitionControl: IncomingBytesPerSecond OutgoingBytesPerSecond
- EventData.SerializedSizeInBytes is used to calculate KB/sec in the partitionlistenercontrol
- Added new properties (LastEnqueuedOffset and LastEnqueuedTimeUtc) to PartitionDescription control 
- Fixed visualization of event data properties in the partition listener control
- Greatly improved message tracking and clear of the partition listener control
- Relay Message saved to file
- Support for Persistent and Dynamic Relay Services
- Export Persistent Relay Services
- Event Hub Metrics
- All Metric
- Partition Consumer
- Added Metrics to consumer groups 
- New behavior: no chart is shown if a metric doesn't have any data
notification hubs metrics



