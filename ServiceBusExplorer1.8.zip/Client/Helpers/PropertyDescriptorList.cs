#region Using Directives
using System.Collections.Generic; 
#endregion

namespace Microsoft.AppFabric.CAT.WindowsAzure.Samples.ServiceBusExplorer
{
    internal class PropertyDescriptorList : List<CustomPropertyDescriptor>
    {
    }
}